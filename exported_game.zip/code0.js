gdjs.Title_32SceneCode = {};
gdjs.Title_32SceneCode.localVariables = [];
gdjs.Title_32SceneCode.GDui_9595closescreenObjects1= [];
gdjs.Title_32SceneCode.GDui_9595closescreenObjects2= [];
gdjs.Title_32SceneCode.GDui_9595closescreenObjects3= [];
gdjs.Title_32SceneCode.GDui_9595closescreenObjects4= [];
gdjs.Title_32SceneCode.GDui_9595chalkObjects1= [];
gdjs.Title_32SceneCode.GDui_9595chalkObjects2= [];
gdjs.Title_32SceneCode.GDui_9595chalkObjects3= [];
gdjs.Title_32SceneCode.GDui_9595chalkObjects4= [];
gdjs.Title_32SceneCode.GDui_9595startscreenObjects1= [];
gdjs.Title_32SceneCode.GDui_9595startscreenObjects2= [];
gdjs.Title_32SceneCode.GDui_9595startscreenObjects3= [];
gdjs.Title_32SceneCode.GDui_9595startscreenObjects4= [];
gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects1= [];
gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects2= [];
gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects3= [];
gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects4= [];
gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects1= [];
gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects2= [];
gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects3= [];
gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects4= [];
gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects1= [];
gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects2= [];
gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects3= [];
gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects4= [];
gdjs.Title_32SceneCode.GDcredit_9595textObjects1= [];
gdjs.Title_32SceneCode.GDcredit_9595textObjects2= [];
gdjs.Title_32SceneCode.GDcredit_9595textObjects3= [];
gdjs.Title_32SceneCode.GDcredit_9595textObjects4= [];
gdjs.Title_32SceneCode.GDui_9595cursorObjects1= [];
gdjs.Title_32SceneCode.GDui_9595cursorObjects2= [];
gdjs.Title_32SceneCode.GDui_9595cursorObjects3= [];
gdjs.Title_32SceneCode.GDui_9595cursorObjects4= [];


gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595cursorObjects2Objects = Hashtable.newFrom({"ui_cursor": gdjs.Title_32SceneCode.GDui_9595cursorObjects2});
gdjs.Title_32SceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.Title_32SceneCode.GDui_9595cursorObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595cursorObjects2Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "UI Layer");
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ui_cursor"), gdjs.Title_32SceneCode.GDui_9595cursorObjects2);
{for(var i = 0, len = gdjs.Title_32SceneCode.GDui_9595cursorObjects2.length ;i < len;++i) {
    gdjs.Title_32SceneCode.GDui_9595cursorObjects2[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}{gdjs.evtTools.input.hideCursor(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22352364);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "425754__moogy73__zap09.wav", false, 100, 1);
}}

}


};gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595text_95959595newgameObjects2Objects = Hashtable.newFrom({"ui_text_newgame": gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects2});
gdjs.Title_32SceneCode.mapOfEmptyGDcredit_9595textObjects = Hashtable.newFrom({"credit_text": []});
gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595closescreenObjects2Objects = Hashtable.newFrom({"ui_closescreen": gdjs.Title_32SceneCode.GDui_9595closescreenObjects2});
gdjs.Title_32SceneCode.asyncCallback22355996 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Title_32SceneCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Loading Scene", false);
}gdjs.Title_32SceneCode.localVariables.length = 0;
}
gdjs.Title_32SceneCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Title_32SceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Title_32SceneCode.asyncCallback22355996(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32SceneCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22354516);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ui_chalk"), gdjs.Title_32SceneCode.GDui_9595chalkObjects3);
{for(var i = 0, len = gdjs.Title_32SceneCode.GDui_9595chalkObjects3.length ;i < len;++i) {
    gdjs.Title_32SceneCode.GDui_9595chalkObjects3[i].getBehavior("Animation").setAnimationName("hover");
}
}{for(var i = 0, len = gdjs.Title_32SceneCode.GDui_9595chalkObjects3.length ;i < len;++i) {
    gdjs.Title_32SceneCode.GDui_9595chalkObjects3[i].setPosition(82,102);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32SceneCode.mapOfEmptyGDcredit_9595textObjects) < 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22355428);
}
}
}
if (isConditionTrue_0) {
gdjs.Title_32SceneCode.GDui_9595closescreenObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595closescreenObjects2Objects, 0, -(10), "");
}
{ //Subevents
gdjs.Title_32SceneCode.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595text_95959595loadgameObjects2Objects = Hashtable.newFrom({"ui_text_loadgame": gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects2});
gdjs.Title_32SceneCode.mapOfEmptyGDcredit_9595textObjects = Hashtable.newFrom({"credit_text": []});
gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595closescreenObjects2Objects = Hashtable.newFrom({"ui_closescreen": gdjs.Title_32SceneCode.GDui_9595closescreenObjects2});
gdjs.Title_32SceneCode.asyncCallback22362516 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Title_32SceneCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Loading Scene", false);
}gdjs.Title_32SceneCode.localVariables.length = 0;
}
gdjs.Title_32SceneCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Title_32SceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Title_32SceneCode.asyncCallback22362516(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32SceneCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("storage", "userGoldCount");
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "userGoldCount", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(0));
}{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "userCloverCount", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(1));
}{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "userPaperCount", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(2));
}{gdjs.evtTools.storage.readNumberFromJSONFile("storage", "userPackageCount", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(3));
}{gdjs.evtTools.storage.readStringFromJSONFile("storage", "wallpaperColor", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(7));
}{gdjs.evtTools.storage.readStringFromJSONFile("storage", "userHavingCostume", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(1));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(4));
}{gdjs.evtTools.storage.readStringFromJSONFile("storage", "userPuttingCostume", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(2));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(5));
}{gdjs.evtTools.storage.readStringFromJSONFile("storage", "userEventOpened", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(3));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(3).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(6));
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.Title_32SceneCode.GDui_9595closescreenObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595closescreenObjects2Objects, 0, -(10), "");
}
{ //Subevents
gdjs.Title_32SceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32SceneCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22357476);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ui_chalk"), gdjs.Title_32SceneCode.GDui_9595chalkObjects3);
{for(var i = 0, len = gdjs.Title_32SceneCode.GDui_9595chalkObjects3.length ;i < len;++i) {
    gdjs.Title_32SceneCode.GDui_9595chalkObjects3[i].getBehavior("Animation").setAnimationName("hover");
}
}{for(var i = 0, len = gdjs.Title_32SceneCode.GDui_9595chalkObjects3.length ;i < len;++i) {
    gdjs.Title_32SceneCode.GDui_9595chalkObjects3[i].setPosition(82,112);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32SceneCode.mapOfEmptyGDcredit_9595textObjects) < 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22358660);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Title_32SceneCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595text_95959595creditsObjects2Objects = Hashtable.newFrom({"ui_text_credits": gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects2});
gdjs.Title_32SceneCode.mapOfEmptyGDcredit_9595textObjects = Hashtable.newFrom({"credit_text": []});
gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595closescreenObjects2Objects = Hashtable.newFrom({"ui_closescreen": gdjs.Title_32SceneCode.GDui_9595closescreenObjects2});
gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDcredit_95959595textObjects2Objects = Hashtable.newFrom({"credit_text": gdjs.Title_32SceneCode.GDcredit_9595textObjects2});
gdjs.Title_32SceneCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22363756);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ui_chalk"), gdjs.Title_32SceneCode.GDui_9595chalkObjects3);
{for(var i = 0, len = gdjs.Title_32SceneCode.GDui_9595chalkObjects3.length ;i < len;++i) {
    gdjs.Title_32SceneCode.GDui_9595chalkObjects3[i].getBehavior("Animation").setAnimationName("hover");
}
}{for(var i = 0, len = gdjs.Title_32SceneCode.GDui_9595chalkObjects3.length ;i < len;++i) {
    gdjs.Title_32SceneCode.GDui_9595chalkObjects3[i].setPosition(82,122);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32SceneCode.mapOfEmptyGDcredit_9595textObjects) < 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22365084);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects2 */
gdjs.Title_32SceneCode.GDcredit_9595textObjects2.length = 0;

gdjs.Title_32SceneCode.GDui_9595closescreenObjects2.length = 0;

{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595closescreenObjects2Objects, 0, -(10), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDcredit_95959595textObjects2Objects, 1920 / 2 - 1100 / 2, 1970, "Text layer");
}{for(var i = 0, len = gdjs.Title_32SceneCode.GDcredit_9595textObjects2.length ;i < len;++i) {
    gdjs.Title_32SceneCode.GDcredit_9595textObjects2[i].setWrappingWidth(1100);
}
}{for(var i = 0, len = gdjs.Title_32SceneCode.GDcredit_9595textObjects2.length ;i < len;++i) {
    gdjs.Title_32SceneCode.GDcredit_9595textObjects2[i].setWrapping(true);
}
}{for(var i = 0, len = gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects2.length ;i < len;++i) {
    gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects2[i].resetTimer("creditTimer");
}
}{for(var i = 0, len = gdjs.Title_32SceneCode.GDcredit_9595textObjects2.length ;i < len;++i) {
    gdjs.Title_32SceneCode.GDcredit_9595textObjects2[i].getBehavior("Tween").addObjectPositionYTween2("creditScroll", -(3000), "linear", 60, true);
}
}}

}


};gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595text_95959595newgameObjects1Objects = Hashtable.newFrom({"ui_text_newgame": gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects1});
gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595text_95959595loadgameObjects1Objects = Hashtable.newFrom({"ui_text_loadgame": gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects1});
gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595text_95959595creditsObjects1Objects = Hashtable.newFrom({"ui_text_credits": gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects1});
gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595text_95959595newgameObjects2Objects = Hashtable.newFrom({"ui_text_newgame": gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects2});
gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595text_95959595loadgameObjects2Objects = Hashtable.newFrom({"ui_text_loadgame": gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects2});
gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595text_95959595creditsObjects2Objects = Hashtable.newFrom({"ui_text_credits": gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects2});
gdjs.Title_32SceneCode.eventsList7 = function(runtimeScene, asyncObjectsList) {

{

gdjs.copyArray(asyncObjectsList.getObjects("ui_text_credits"), gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("ui_text_loadgame"), gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("ui_text_newgame"), gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595text_95959595newgameObjects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595text_95959595loadgameObjects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595text_95959595creditsObjects2Objects, runtimeScene, true, true);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(asyncObjectsList.getObjects("ui_chalk"), gdjs.Title_32SceneCode.GDui_9595chalkObjects2);

{for(var i = 0, len = gdjs.Title_32SceneCode.GDui_9595chalkObjects2.length ;i < len;++i) {
    gdjs.Title_32SceneCode.GDui_9595chalkObjects2[i].getBehavior("Animation").setAnimationName("waiting");
}
}{for(var i = 0, len = gdjs.Title_32SceneCode.GDui_9595chalkObjects2.length ;i < len;++i) {
    gdjs.Title_32SceneCode.GDui_9595chalkObjects2[i].setPosition(89,110);
}
}}

}


};gdjs.Title_32SceneCode.asyncCallback22369956 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Title_32SceneCode.localVariables);

{ //Subevents
gdjs.Title_32SceneCode.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Title_32SceneCode.localVariables.length = 0;
}
gdjs.Title_32SceneCode.eventsList8 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Title_32SceneCode.localVariables);
for (const obj of gdjs.Title_32SceneCode.GDui_9595chalkObjects1) asyncObjectsList.addObject("ui_chalk", obj);
for (const obj of gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects1) asyncObjectsList.addObject("ui_text_credits", obj);
for (const obj of gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects1) asyncObjectsList.addObject("ui_text_loadgame", obj);
for (const obj of gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects1) asyncObjectsList.addObject("ui_text_newgame", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.8), (runtimeScene) => (gdjs.Title_32SceneCode.asyncCallback22369956(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Title_32SceneCode.eventsList9 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("ui_text_newgame"), gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595text_95959595newgameObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Title_32SceneCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("ui_text_loadgame"), gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595text_95959595loadgameObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Title_32SceneCode.eventsList5(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("ui_text_credits"), gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595text_95959595creditsObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Title_32SceneCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ui_text_credits"), gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects2.length;i<l;++i) {
    if ( gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects2[i].getTimerElapsedTimeInSecondsOrNaN("creditTimer") >= 2 ) {
        isConditionTrue_0 = true;
        gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects2[k] = gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects2[i];
        ++k;
    }
}
gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("credit_text"), gdjs.Title_32SceneCode.GDcredit_9595textObjects2);
gdjs.copyArray(runtimeScene.getObjects("ui_closescreen"), gdjs.Title_32SceneCode.GDui_9595closescreenObjects2);
{for(var i = 0, len = gdjs.Title_32SceneCode.GDcredit_9595textObjects2.length ;i < len;++i) {
    gdjs.Title_32SceneCode.GDcredit_9595textObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Title_32SceneCode.GDui_9595closescreenObjects2.length ;i < len;++i) {
    gdjs.Title_32SceneCode.GDui_9595closescreenObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("ui_chalk"), gdjs.Title_32SceneCode.GDui_9595chalkObjects1);
gdjs.copyArray(runtimeScene.getObjects("ui_text_credits"), gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects1);
gdjs.copyArray(runtimeScene.getObjects("ui_text_loadgame"), gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects1);
gdjs.copyArray(runtimeScene.getObjects("ui_text_newgame"), gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595text_95959595newgameObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595text_95959595loadgameObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Title_32SceneCode.mapOfGDgdjs_9546Title_959532SceneCode_9546GDui_95959595text_95959595creditsObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Title_32SceneCode.GDui_9595chalkObjects1.length;i<l;++i) {
    if ( gdjs.Title_32SceneCode.GDui_9595chalkObjects1[i].getBehavior("Animation").getAnimationName() != "waiting" ) {
        isConditionTrue_0 = true;
        gdjs.Title_32SceneCode.GDui_9595chalkObjects1[k] = gdjs.Title_32SceneCode.GDui_9595chalkObjects1[i];
        ++k;
    }
}
gdjs.Title_32SceneCode.GDui_9595chalkObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22369740);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Title_32SceneCode.GDui_9595chalkObjects1 */
{for(var i = 0, len = gdjs.Title_32SceneCode.GDui_9595chalkObjects1.length ;i < len;++i) {
    gdjs.Title_32SceneCode.GDui_9595chalkObjects1[i].getBehavior("Animation").setAnimationName("out");
}
}
{ //Subevents
gdjs.Title_32SceneCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.Title_32SceneCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 10, "", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, 96, "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, 98.5, "", 0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "522297__mrthenoronha__placeful-song-loop.wav", true, 100, 1);
}}

}


{


gdjs.Title_32SceneCode.eventsList0(runtimeScene);
}


{


gdjs.Title_32SceneCode.eventsList9(runtimeScene);
}


};

gdjs.Title_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Title_32SceneCode.GDui_9595closescreenObjects1.length = 0;
gdjs.Title_32SceneCode.GDui_9595closescreenObjects2.length = 0;
gdjs.Title_32SceneCode.GDui_9595closescreenObjects3.length = 0;
gdjs.Title_32SceneCode.GDui_9595closescreenObjects4.length = 0;
gdjs.Title_32SceneCode.GDui_9595chalkObjects1.length = 0;
gdjs.Title_32SceneCode.GDui_9595chalkObjects2.length = 0;
gdjs.Title_32SceneCode.GDui_9595chalkObjects3.length = 0;
gdjs.Title_32SceneCode.GDui_9595chalkObjects4.length = 0;
gdjs.Title_32SceneCode.GDui_9595startscreenObjects1.length = 0;
gdjs.Title_32SceneCode.GDui_9595startscreenObjects2.length = 0;
gdjs.Title_32SceneCode.GDui_9595startscreenObjects3.length = 0;
gdjs.Title_32SceneCode.GDui_9595startscreenObjects4.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects1.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects2.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects3.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects4.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects1.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects2.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects3.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects4.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects1.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects2.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects3.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects4.length = 0;
gdjs.Title_32SceneCode.GDcredit_9595textObjects1.length = 0;
gdjs.Title_32SceneCode.GDcredit_9595textObjects2.length = 0;
gdjs.Title_32SceneCode.GDcredit_9595textObjects3.length = 0;
gdjs.Title_32SceneCode.GDcredit_9595textObjects4.length = 0;
gdjs.Title_32SceneCode.GDui_9595cursorObjects1.length = 0;
gdjs.Title_32SceneCode.GDui_9595cursorObjects2.length = 0;
gdjs.Title_32SceneCode.GDui_9595cursorObjects3.length = 0;
gdjs.Title_32SceneCode.GDui_9595cursorObjects4.length = 0;

gdjs.Title_32SceneCode.eventsList10(runtimeScene);
gdjs.Title_32SceneCode.GDui_9595closescreenObjects1.length = 0;
gdjs.Title_32SceneCode.GDui_9595closescreenObjects2.length = 0;
gdjs.Title_32SceneCode.GDui_9595closescreenObjects3.length = 0;
gdjs.Title_32SceneCode.GDui_9595closescreenObjects4.length = 0;
gdjs.Title_32SceneCode.GDui_9595chalkObjects1.length = 0;
gdjs.Title_32SceneCode.GDui_9595chalkObjects2.length = 0;
gdjs.Title_32SceneCode.GDui_9595chalkObjects3.length = 0;
gdjs.Title_32SceneCode.GDui_9595chalkObjects4.length = 0;
gdjs.Title_32SceneCode.GDui_9595startscreenObjects1.length = 0;
gdjs.Title_32SceneCode.GDui_9595startscreenObjects2.length = 0;
gdjs.Title_32SceneCode.GDui_9595startscreenObjects3.length = 0;
gdjs.Title_32SceneCode.GDui_9595startscreenObjects4.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects1.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects2.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects3.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595newgameObjects4.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects1.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects2.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects3.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595loadgameObjects4.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects1.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects2.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects3.length = 0;
gdjs.Title_32SceneCode.GDui_9595text_9595creditsObjects4.length = 0;
gdjs.Title_32SceneCode.GDcredit_9595textObjects1.length = 0;
gdjs.Title_32SceneCode.GDcredit_9595textObjects2.length = 0;
gdjs.Title_32SceneCode.GDcredit_9595textObjects3.length = 0;
gdjs.Title_32SceneCode.GDcredit_9595textObjects4.length = 0;
gdjs.Title_32SceneCode.GDui_9595cursorObjects1.length = 0;
gdjs.Title_32SceneCode.GDui_9595cursorObjects2.length = 0;
gdjs.Title_32SceneCode.GDui_9595cursorObjects3.length = 0;
gdjs.Title_32SceneCode.GDui_9595cursorObjects4.length = 0;


return;

}

gdjs['Title_32SceneCode'] = gdjs.Title_32SceneCode;
