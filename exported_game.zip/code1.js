gdjs.Loading_32SceneCode = {};
gdjs.Loading_32SceneCode.localVariables = [];
gdjs.Loading_32SceneCode.GDloadingObjects1= [];
gdjs.Loading_32SceneCode.GDloadingObjects2= [];


gdjs.Loading_32SceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.prioritizeLoadingOfScene(runtimeScene, "Store Scene");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.areSceneAssetsLoaded(runtimeScene, "Store Scene");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Store Scene", false);
}}

}


};

gdjs.Loading_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Loading_32SceneCode.GDloadingObjects1.length = 0;
gdjs.Loading_32SceneCode.GDloadingObjects2.length = 0;

gdjs.Loading_32SceneCode.eventsList0(runtimeScene);
gdjs.Loading_32SceneCode.GDloadingObjects1.length = 0;
gdjs.Loading_32SceneCode.GDloadingObjects2.length = 0;


return;

}

gdjs['Loading_32SceneCode'] = gdjs.Loading_32SceneCode;
